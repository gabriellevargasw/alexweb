from flask import Flask, render_template, request


#Objetivo: Importar as classes e funções necessárias do Flask.

#Flask: Classe principal para criar a aplicação.

#render_template: Função para renderizar templates HTML.

#request: Objeto que contém os dados da requisição HTTP, como os dados enviados por formulários.

#*******************************************************************************************************************

app = Flask(__name__)

# Rota para a página principal
@app.route('/')
def home():
    return render_template('index.html')


#Objetivo: Definir a rota para a página inicial.

#@app.route('/'): Decorador que associa a função home à URL raiz (/).

#render_template('index.html'): Renderiza o template HTML index.html quando a rota é acessada.

#**************************************************************************************************************


# Rota para a Página com o formulário
@app.route('/cadastro')
def cadastro():
    return render_template('cadastro.html')



#Objetivo: Definir a rota para a página de cadastro.

#@app.route('/cadastro'): Decorador que associa a função cadastro à URL /cadastro.

#render_template('cadastro.html'): Renderiza o template HTML cadastro.html quando a rota é acessada.

#**************************************************************************************************************


# Rota que recebe os dados do formulário
@app.route('/cadastro', methods=['POST'])


def cadastro_post():
    	
    nome = request.form['nome']
    email = request.form['email']
    
    # Aqui você pode salvar no banco ou processar os dados
    # Por enquanto, vamos apenas mostrar na tela
    return render_template('sucesso.html', nome=nome, email=email)


#Objetivo: Definir a rota para processar os dados enviados pelo formulário de cadastro.

#@app.route('/cadastro', methods=['POST']): Decorador que associa a função cadastro_post à URL /cadastro para requisições do tipo POST.

#request.form['nome']: Obtém o valor do campo nome enviado pelo formulário.

#request.form['email']: Obtém o valor do campo email enviado pelo formulário.

#render_template('sucesso.html', nome=nome, email=email): Renderiza o template HTML sucesso.html, passando os valores de nome e email como variáveis para o template.

#**************************************************************************************************************


if __name__ == '__main__':
    app.run(debug=True)



#Objetivo: Executar a aplicação Flask.

#if __name__ == '__main__': Garante que o código dentro do bloco seja executado apenas quando o script for executado diretamente, e não quando for importado como módulo.

#app.run(debug=True): Inicia o servidor de desenvolvimento do Flask com o modo de depuração ativado, permitindo recarregamento automático e exibição de erros detalhados.

#**************************************************************************************************************


#Estrutura de Diretórios Sugerida
#Para que o código funcione corretamente, é necessário organizar os arquivos da seguinte forma:


#meu_app/
#│
#├── app.py              # Arquivo principal da aplicação Flask
#├── templates/          # Diretório contendo os templates HTML
#│   ├── index.html      # Template da página inicial
#│   ├── cadastro.html   # Template do formulário de cadastro
#│   └── sucesso.html    # Template da página de sucesso
#└── static/             # Diretório para arquivos estáticos (CSS, JS, imagens)
#    └── style.css       # Arquivo CSS para estilização
#templates/: Contém os arquivos HTML que serão renderizados pelo Flask.

#static/: Contém arquivos estáticos como CSS, JavaScript e imagens.






